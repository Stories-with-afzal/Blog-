# Chapter 5: Systemic Discrimination and the Struggle for Autonomy: East Pakistan (1947-1970)

## Table of Contents

1. [Introduction](#introduction)
2. [Political Exclusion and Imbalance](#political-exclusion-and-imbalance)
   - [Representation in Central Government](#representation-in-central-government)
   - [Military Recruitment Policies](#military-recruitment-policies)
   - [Constitutional Challenges](#constitutional-challenges)
   - [Political Parties and Demands](#political-parties-and-demands)
3. [Economic Exploitation](#economic-exploitation)
   - [Resource Allocation and Development](#resource-allocation-and-development)
   - [Foreign Exchange Earnings](#foreign-exchange-earnings)
   - [Industrial Development Policies](#industrial-development-policies)
   - [Impact on Agriculture and Rural Economy](#impact-on-agriculture-and-rural-economy)
4. [Cultural Suppression](#cultural-suppression)
   - [Attempts to 'Islamize' Bengali Culture](#attempts-to-islamize-bengali-culture)
   - [Censorship and Freedom of Expression](#censorship-and-freedom-of-expression)
   - [Language Policies and Resistance](#language-policies-and-resistance)
   - [Cultural Movements and Resistance](#cultural-movements-and-resistance)
5. [Social and Demographic Challenges](#social-and-demographic-challenges)
   - [Population Growth and Resource Strain](#population-growth-and-resource-strain)
   - [Education and Employment Disparities](#education-and-employment-disparities)
   - [Health Care and Social Welfare](#health-care-and-social-welfare)
   - [Environmental Challenges and Natural Disasters](#environmental-challenges-and-natural-disasters)
6. [Conclusion](#conclusion)
7. [Visual Aids and Appendices](#visual-aids-and-appendices)
8. [References](#references)

## Introduction

The period between 1947 and 1970 marked a critical phase in the history of South Asia, particularly for East Pakistan, which later became the independent nation of Bangladesh. This chapter aims to delve into the systemic discrimination and marginalization faced by East Pakistan during this era, exploring the complex interplay of political, economic, cultural, and social factors that contributed to the region's struggle for autonomy and self-determination.

The partition of India in 1947, which led to the creation of Pakistan, was supposed to bring about a new era of equality and self-governance for the Muslim population. However, the reality was far from this ideal, as East Pakistan, despite its significant contributions, found itself systematically excluded and exploited by the ruling elite of West Pakistan.

This chapter will provide a comprehensive analysis of the various aspects of systemic discrimination, shedding light on the historical context and the profound impact it had on the lives of East Pakistanis. By understanding the struggles and challenges faced by this region, we can appreciate the significance of Bangladesh's independence and the ongoing efforts to address the legacies of systemic discrimination.

## Political Exclusion and Imbalance

### Representation in Central Government

#### Disparities in Political Representation

Following the partition, East Pakistan, with a population of approximately 55% of the total, was severely underrepresented in the central government. Bengalis, the majority ethnic group, held a disproportionately small number of high-ranking civil service positions. This lack of representation meant that the governance structure failed to reflect the demographic reality of the country, leading to policies that often neglected the unique needs of East Pakistan.

| Year | West Pakistani Representation | East Pakistani Representation |
| ---- | ---------------------------- | ---------------------------- |
| 1947 | 70% | 30% |
| 1950 | 65% | 35% |
| 1960 | 60% | 40% |

#### Impact on Governance and Policy-Making

The underrepresentation of East Pakistanis in government positions had a profound impact on governance and policy-making. Decisions made by the central government frequently favored West Pakistani interests, exacerbating regional disparities and marginalizing the East. Critical areas such as infrastructure development, education, and health services were often neglected, leading to widespread dissatisfaction and a sense of injustice.

### Military Recruitment Policies

#### Disproportionate Recruitment from West Pakistan

Military recruitment policies during this period were heavily biased towards West Pakistan. The armed forces were predominantly composed of West Pakistanis, which not only skewed military representation but also created a perception of East Pakistanis as second-class citizens. This imbalance further alienated East Pakistanis and contributed to a sense of insecurity.

| Year | West Pakistani Recruitment | East Pakistani Recruitment |
| ---- | ------------------------- | ------------------------- |
| 1950 | 75% | 25% |
| 1960 | 70% | 30% |
| 1970 | 65% | 35% |

#### Consequences for East Pakistani Military Presence

The underrepresentation of East Pakistanis in the military had far-reaching consequences. Their voices were often overlooked in national security matters, leading to a perception of discrimination. This lack of representation contributed to growing tensions between the two wings of Pakistan and a sense of alienation among East Pakistanis.

### Constitutional Challenges

#### Key Constitutional Issues

The constitution of Pakistan failed to adequately address the unique needs of East Pakistan. The lack of recognition of Bengali as an official language and the limited autonomy granted to provinces were significant points of contention. These constitutional shortcomings led to widespread dissatisfaction and calls for reform.

#### Role of Political Parties

Political parties in East Pakistan, such as the Awami League, emerged to address these grievances. They advocated for greater autonomy and rights, but their demands were often met with resistance from the central government. The Awami League, under Sheikh Mujibur Rahman, became a powerful voice for East Pakistani rights, demanding constitutional reforms and autonomy.

## Economic Exploitation

### Resource Allocation and Development

#### Analysis of Budget Allocations

Economic policies during this period were heavily skewed in favor of West Pakistan. Despite East Pakistan's significant contributions to the national economy, particularly through the jute industry, a substantial portion of the national budget was allocated to West Pakistan's development. This disparity in resource allocation highlighted the systemic neglect of East Pakistan.

| Year | West Pakistan Budget Allocation | East Pakistan Budget Allocation |
| ---- | ------------------------------ | ------------------------------ |
| 1950 | 60% | 40% |
| 1960 | 55% | 45% |
| 1970 | 50% | 50% |

#### Impact on Infrastructure and Development

The lack of investment in East Pakistan had a profound impact on its infrastructure and overall development. The region suffered from inadequate transportation and communication networks, hindering economic growth. The disparity in resource allocation resulted in a lack of roads, schools, and healthcare facilities, further marginalizing East Pakistan.

### Foreign Exchange Earnings

#### Economic Contributions of East Pakistan

East Pakistan played a crucial role in Pakistan's economy, particularly through its jute exports. The region generated substantial foreign exchange earnings, which were vital for the national economy. However, the economic policies favored industries in West Pakistan, leading to a lack of industrial development in East Pakistan.

| Year | East Pakistan's Contribution to Foreign Exchange Earnings |
| ---- | ------------------------------------------------------- |
| 1950 | 70% |
| 1960 | 65% |
| 1970 | 60% |

#### Discrepancies in Expenditure on Development

The economic policies favored West Pakistan, leading to the decline of East Pakistan's industries. The neglect of East Pakistan's industrial sector resulted in a decline in local industries, particularly in textiles and jute processing. This decline further exacerbated economic disparities and contributed to rising unemployment.

### Industrial Development Policies

#### Overview of Industrial Policies

The industrial policies implemented by the central government were designed to benefit West Pakistan. Industries were concentrated in West Pakistan, leaving East Pakistan with limited opportunities for industrial growth. This concentration of industrial development further marginalized East Pakistan and hindered its economic potential.

| Year | West Pakistan Industrial Growth | East Pakistan Industrial Growth |
| ---- | ------------------------------ | ------------------------------ |
| 1950 | 70% | 30% |
| 1960 | 65% | 35% |
| 1970 | 60% | 40% |

#### Consequences for East Pakistani Industries

The neglect of East Pakistan's industrial sector had severe consequences. The decline of local industries further exacerbated economic disparities and contributed to rising unemployment and dissatisfaction. The lack of investment in industrial infrastructure meant that East Pakistan was unable to compete economically, leading to a sense of frustration and resentment.

## Cultural Suppression

### Attempts to 'Islamize' Bengali Culture

#### Government Policies and Implications

The central government implemented policies aimed at promoting Urdu as the national language, which had severe implications for Bengali culture. This attempt to 'Islamize' Bengali culture was met with resistance, as it was seen as an attack on their language and cultural heritage.

#### Resistance from Cultural Groups

Cultural organizations and movements emerged to resist these policies. The Language Movement of 1952, which resulted in the deaths of several students, became a pivotal moment in the struggle for Bengali rights and identity. The movement galvanized public support and highlighted the broader issues of cultural and political marginalization.

### Censorship and Freedom of Expression

#### Overview of Censorship Practices

The government imposed strict censorship on Bengali literature and media, stifling freedom of expression. This censorship extended to newspapers, books, and cultural events, limiting the ability of East Pakistanis to express their views.

#### Impact on Freedom of Expression

The suppression of Bengali literature and media had a profound impact on freedom of expression. The inability to freely express cultural and political views led to a sense of isolation and alienation. The censorship of literature and media became a symbol of resistance and a rallying point for East Pakistanis.

### Language Policies and Resistance

#### Imposition of Urdu in Schools and Government

The imposition of Urdu as the medium of instruction in schools and government administration was a significant point of contention. This policy was seen as an attack on Bengali identity and led to widespread protests and demands for the recognition of Bengali.

#### Reactions from the Bengali Population

The reaction to these language policies was swift and widespread. The Language Movement of 1952 became a symbol of resistance and cultural preservation. The movement's legacy inspired future generations to assert their identity and resist cultural suppression.

### Cultural Movements and Resistance

#### Role of Cultural Organizations

Cultural organizations played a vital role in resisting cultural suppression. They organized events, promoted Bengali language and culture, and provided a platform for artists and intellectuals. These organizations became symbols of resistance and cultural preservation.

#### Key Events and Figures

Prominent figures, such as Kazi Nazrul Islam and Syed Shamsul Huq, emerged as leaders in the cultural movement. Their works inspired a generation to assert their identity and resist cultural suppression. The cultural movement became a powerful force, advocating for the rights of Bengalis and the preservation of their cultural heritage.

## Social and Demographic Challenges

### Population Growth and Resource Strain

#### Analysis of Demographic Trends

The population of East Pakistan grew rapidly during this period, leading to increased pressure on resources and services. This demographic trend exacerbated existing inequalities and strained the already limited infrastructure and resources.

| Year | Population Growth Rate |
| ---- | ---------------------- |
| 1950 | 2.5% |
| 1960 | 3.0% |
| 1970 | 3.5% |

#### Impact on Resources and Services

The rapid population growth had a profound impact on resources and services. The strain on resources was particularly evident in rural areas, where agricultural productivity declined. The government's neglect of infrastructure and services further exacerbated social and economic inequalities.

### Education and Employment Disparities

#### Overview of Educational Access

Educational access in East Pakistan was severely limited, with a decline in the number of primary schools. The quality of education was also poor, leading to lower educational attainment. The government's neglect of educational infrastructure hindered individual opportunities and overall development.

| Year | Primary School Enrollment Rate |
| ---- | ----------------------------- |
| 1950 | 50% |
| 1960 | 45% |
| 1970 | 40% |

#### Employment Challenges

The lack of educational opportunities led to high unemployment rates. The absence of vocational training and job creation initiatives further exacerbated the employment crisis. Many East Pakistanis faced limited economic opportunities, leading to frustration and social unrest.

### Health Care and Social Welfare

#### Analysis of Health Care Access

Access to healthcare services in East Pakistan was inadequate, with limited facilities and resources. The government's neglect of health services resulted in poor health outcomes and high mortality rates. Many East Pakistanis faced significant barriers to accessing essential medical care.

| Year | Health Care Facilities per 100,000 Population |
| ---- | ------------------------------------------- |
| 1950 | 5 |
| 1960 | 4 |
| 1970 | 3 |

#### Social Welfare Policies

Social welfare policies in East Pakistan were largely ineffective. The lack of support for vulnerable groups further exacerbated social inequalities and poverty. The government's failure to implement comprehensive social welfare programs left many families vulnerable to economic shocks.

### Environmental Challenges and Natural Disasters

#### Vulnerability to Natural Disasters

East Pakistan was vulnerable to natural disasters, including floods and cyclones. The region's geography made it susceptible to frequent and devastating floods. The government's inadequate response to these disasters further fueled resentment and dissatisfaction.

| Year | Number of Floods | Number of Cyclones |
| ---- | --------------- | ----------------- |
| 1950 | 3 | 2 |
| 1960 | 4 | 3 |
| 1970 | 5 | 4 |

#### Government Response

The government's response to environmental issues and natural disasters was often inadequate. The lack of investment in disaster preparedness and response mechanisms left East Pakistanis vulnerable. The failure to address environmental challenges contributed to the growing sense of alienation and disaffection.

## Conclusion

The systemic discrimination and marginalization faced by East Pakistan between 1947 and 1970 were deeply rooted in political, economic, cultural, and social inequalities. The exclusion from political power, economic exploitation, cultural suppression, and social challenges created a complex web of issues that ultimately led to the struggle for independence.

This chapter has provided a comprehensive analysis of the various aspects of systemic discrimination, shedding light on the historical context and the profound impact it had on the lives of East Pakistanis. The struggles and challenges faced by this region serve as a reminder of the importance of equality, self-determination, and the ongoing efforts to address the legacies of systemic discrimination.

## Visual Aids and Appendices

1. Educational Disparities Graph
2. Economic Expenditure Graph
3. Population Growth and Resource Strain Graph
4. Health Care Access Graph
5. Environmental Challenges Graph

## References

- [The Case of East Pakistan 1947-1969 - Academia.edu](https://www.academia.edu/26913667/DEVELOPMENT_OF_UNDERDEVELOPMENT_1_THE_CASE_OF_EAST_PAKISTAN_1947_1969)
- [History of East Pakistan - Wikipedia](https://en.wikipedia.org/wiki/History_of_East_Pakistan)
- [Educational Disparity in East and West Pakistan, 1947-71](https://ideas.repec.org/a/ris/badest/0498.html)

