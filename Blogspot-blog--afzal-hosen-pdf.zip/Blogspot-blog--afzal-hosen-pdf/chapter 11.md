# Chapter 11: India’s Role: Diplomatic and Military Involvement in the 1971 War

## 1. India’s Strategic Calculations (12,500 words)
- **Initial Response to the Crisis in East Pakistan**
  - Overview of India’s early reactions
  - Key decisions made by Indian leadership
- **Refugee Influx and Its Impact on Indian States**
  - Overview of the refugee crisis
  - Consequences for Indian states bordering East Pakistan
- **Domestic Political Considerations in India**
  - Overview of political dynamics in India
  - Impact on government policies
- **Long-term Strategic Interests in the Region**
  - Overview of India’s strategic goals
  - Implications for regional stability

## 2. India’s Diplomatic Offensive (12,500 words)
- **Indira Gandhi’s Global Tour and Advocacy**
  - Overview of Gandhi’s diplomatic efforts
  - Key meetings and outcomes
- **Negotiations with Major World Powers**
  - Overview of negotiations with the U.S. and USSR
  - Impact on international relations
- **Efforts to Garner Support in the United Nations**
  - Overview of India’s initiatives in the UN
  - Key resolutions and statements
- **The Indo-Soviet Treaty of Friendship and Cooperation**
  - Overview of the treaty’s significance
  - Impact on India’s military strategy

## 3. India’s Military Preparations and Strategy (12,500 words)
- **Military Build-up Along the Border**
  - Overview of military deployments
  - Key strategies employed
- **Coordination with Mukti Bahini Forces**
  - Overview of joint operations
  - Impact on military effectiveness
- **Planning for Potential Full-scale Intervention**
  - Overview of military planning processes
  - Key contingencies considered
- **Naval Blockade and Its Impact**
  - Overview of naval strategies
  - Consequences for the conflict

## 4. India’s Direct Military Intervention (12,500 words)
- **Events Leading to India’s Entry into the War**
  - Overview of key events prompting intervention
  - Timeline of military actions
- **Major Battles and Military Operations**
  - Overview of significant battles
  - Key outcomes and implications
- **Air and Naval Campaigns**
  - Overview of air and naval strategies
  - Impact on the overall war effort
- **Coordination Between Indian Forces and Mukti Bahini**
  - Overview of joint operations
  - Key successes and challenges faced