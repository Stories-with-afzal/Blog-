# Chapter 4: The Language Movement: A Milestone in Bengali Nationalism (1947-1952)

## Introduction

The Language Movement of 1947-1952 is a defining moment in the history of Bengali nationalism. This period saw the Bengali people's struggle against the imposition of Urdu as the sole national language of Pakistan, culminating in the tragic events of February 21, 1952. The movement not only underscored the linguistic and cultural identity of the Bengali people but also laid the foundation for the eventual independence of Bangladesh. This chapter explores the historical significance of the Bengali language, the initial reactions to the imposition of Urdu, the protests of 1948, the martyrdom of 1952, and the long-term impact of the Language Movement on Bengali nationalism and global linguistic rights.

## Table of Contents

1. [The Role of Language in Defining Bengali Identity](#the-role-of-language-in-defining-bengali-identity)
   - [Historical Importance of the Bengali Language](#historical-importance-of-the-bengali-language)
   - [Linguistic Heritage and Evolution](#linguistic-heritage-and-evolution)
   - [Cultural Significance of Language](#cultural-significance-of-language)
   - [Language Policies in Newly-formed Pakistan](#language-policies-in-newly-formed-pakistan)
   - [Imposition of Urdu as the National Language](#imposition-of-urdu-as-the-national-language)
   - [Initial Reactions to Urdu Imposition in East Pakistan](#initial-reactions-to-urdu-imposition-in-east-pakistan)

2. [Protests of 1948: Early Signs of Resistance](#protests-of-1948-early-signs-of-resistance)
   - [First Language Conference and Student Protests](#first-language-conference-and-student-protests)
   - [Political Leaders’ Stance on the Language Issue](#political-leaders-stance-on-the-language-issue)
   - [Government Response and Suppression Tactics](#government-response-and-suppression-tactics)
   - [Growing Tension Between East and West Pakistan](#growing-tension-between-east-and-west-pakistan)

3. [The Martyrdom of 1952 and Its Symbolism](#the-martyrdom-of-1952-and-its-symbolism)
   - [Events Leading to February 21, 1952](#events-leading-to-february-21-1952)
   - [Details of the Protests and Police Action](#details-of-the-protests-and-police-action)
   - [Profiles of the Language Martyrs](#profiles-of-the-language-martyrs)
   - [Immediate Aftermath and Public Reaction](#immediate-aftermath-and-public-reaction)

4. [Long-term Impact of the Language Movement](#long-term-impact-of-the-language-movement)
   - [Recognition of Bengali as a State Language](#recognition-of-bengali-as-a-state-language)
   - [Influence on Bengali Nationalist Sentiment](#influence-on-bengali-nationalist-sentiment)
   - [Cultural and Literary Responses to the Movement](#cultural-and-literary-responses-to-the-movement)
   - [International Recognition](#international-recognition)

## 1. The Role of Language in Defining Bengali Identity

### a. Historical Importance of the Bengali Language

The Bengali language holds profound historical significance for the Bengali people. Its origins can be traced back to ancient times, evolving through various linguistic and cultural interactions.

#### Origins and Evolution

The Bengali language emerged from the Magadhi Prakrit, spoken in the eastern part of the Indian subcontinent. The earliest known form of Bengali can be found in the Charyapada, a collection of Buddhist mystic songs dating back to the 8th to 12th centuries. These songs, written in a form of Old Bengali, provide valuable insights into the linguistic and cultural heritage of the region.

During the medieval period, Bengali literature flourished under the patronage of various dynasties, including the Pala and Sena dynasties. This period saw the composition of numerous literary works, including the Mangalkavyas (poems of blessing), which celebrated the deeds of local gods and goddesses. These works not only enriched the Bengali language but also played a crucial role in preserving the cultural heritage of the region.

#### Colonial Influence

The British colonial period had a profound impact on the Bengali language. The introduction of the printing press in the late 18th century facilitated the dissemination of Bengali literature and helped standardize the language. However, the colonial administration also imposed English as the medium of education and administration, which led to a decline in the use of Bengali in official domains.

Despite these challenges, Bengali intellectuals and reformers played a crucial role in preserving and promoting the language. Figures like Raja Rammohan Roy and Ishwar Chandra Vidyasagar advocated for the use of Bengali in education and administration. Their efforts culminated in the establishment of the Bengali language as a medium of instruction in schools and colleges, which helped to revitalize the language and strengthen its cultural significance.

### b. Linguistic Heritage and Evolution

The Bengali language is characterized by its unique script, phonology, grammar, and vocabulary. The Bengali script, derived from the Brahmi script, is an abugida, where each consonant has an inherent vowel sound. The script has evolved over centuries, with regional variations and adaptations.

#### Unique Characteristics

The Bengali language has a rich phonetic system, with a wide range of consonant and vowel sounds. The grammar of Bengali is characterized by its complex system of verb conjugations and noun declensions. The language also has a rich vocabulary, with words borrowed from various languages, including Sanskrit, Persian, Arabic, and English.

#### Influence of Other Languages

The Bengali language has been influenced by various languages throughout its history. Sanskrit, the classical language of ancient India, has had a profound impact on Bengali, with numerous loanwords and grammatical structures derived from Sanskrit. Persian and Arabic, introduced during the Muslim rule in Bengal, have also contributed to the Bengali vocabulary, particularly in the domains of administration, religion, and literature.

The British colonial period saw the introduction of English, which had a significant impact on the Bengali language. English loanwords and grammatical structures were incorporated into Bengali, particularly in the domains of science, technology, and administration. This linguistic exchange enriched the Bengali language and facilitated its adaptation to modern contexts.

#### Development of Bengali Literature

Bengali literature has a rich and diverse history, with contributions from various literary genres and movements. The medieval period saw the composition of numerous literary works, including the Mangalkavyas, which celebrated the deeds of local gods and goddesses. These works not only enriched the Bengali language but also played a crucial role in preserving the cultural heritage of the region.

The modern period saw the emergence of new literary genres and movements, including the Bengal Renaissance, which was characterized by a renewed interest in Bengali literature and culture. Figures like Rabindranath Tagore, Bankim Chandra Chattopadhyay, and Sarat Chandra Chattopadhyay made significant contributions to Bengali literature, enriching the language and strengthening its cultural significance.

### c. Cultural Significance of Language

The Bengali language plays a crucial role in shaping the identity and culture of the Bengali people. It is not merely a medium of communication but also a symbol of their cultural heritage and national identity. The language is deeply embedded in various aspects of Bengali life, including education, media, arts, and everyday communication.

#### Role in Shaping Identity

The Bengali language has played a crucial role in shaping the identity of the Bengali people. It has served as a unifying force, bringing together people from diverse backgrounds and regions. The language has also been a source of pride and inspiration, reflecting the rich cultural heritage and literary traditions of the Bengali people.

#### Importance in Daily Life

The Bengali language is an integral part of daily life in Bengal. It is the medium of instruction in schools and colleges, the language of media and entertainment, and the primary means of communication in social and cultural interactions. The language is also deeply embedded in the literary and artistic traditions of the region, with numerous works of literature, music, and art reflecting the richness and diversity of the Bengali language.

### d. Language Policies in Newly-formed Pakistan

The partition of India in 1947 and the creation of Pakistan had significant implications for the Bengali language. The newly-formed Pakistani government adopted a series of language policies that had profound effects on the linguistic and cultural landscape of the country.

#### Government Decisions

One of the most controversial decisions of the Pakistani government was the imposition of Urdu as the sole national language. This decision was made despite the fact that the majority of the population in East Pakistan (now Bangladesh) spoke Bengali. The government justified this decision on the grounds that Urdu was a unifying language that could bridge the cultural and linguistic differences between the various ethnic groups in Pakistan.

#### Implications for Bengali Speakers

The imposition of Urdu as the national language had significant implications for the Bengali-speaking majority in East Pakistan. It was seen as a threat to their linguistic and cultural identity, as it marginalized the Bengali language and undermined its status as a medium of education, administration, and communication. This decision sparked widespread resentment and resistance among the Bengali people, leading to the emergence of the language movement.

### e. Imposition of Urdu as the National Language

The imposition of Urdu as the national language of Pakistan was met with strong opposition from the Bengali-speaking majority in East Pakistan. The decision was seen as an attempt to impose a foreign language on the Bengali people, undermining their linguistic and cultural identity.

#### Initial Reactions

The initial reactions to the imposition of Urdu were characterized by a sense of shock and disbelief among the Bengali people. They saw this decision as a betrayal of their linguistic and cultural heritage, as it marginalized the Bengali language and undermined its status as a medium of education, administration, and communication. This decision sparked widespread resentment and resistance among the Bengali people, leading to the emergence of the language movement.

### f. Initial Reactions to Urdu Imposition in East Pakistan

The imposition of Urdu as the national language of Pakistan sparked widespread protests and public sentiment in East Pakistan. The Bengali people saw this decision as a threat to their linguistic and cultural identity, as it marginalized the Bengali language and undermined its status as a medium of education, administration, and communication.

#### Protests and Public Sentiment

The initial protests against the imposition of Urdu were spontaneous and largely unorganized. They were characterized by a sense of outrage and frustration among the Bengali people, who saw this decision as a betrayal of their linguistic and cultural heritage. These protests were led by students, intellectuals, and cultural activists, who demanded the recognition of Bengali as a national language of Pakistan.

#### Role of Student Organizations

Student organizations played a crucial role in mobilizing and organizing protests against the imposition of Urdu. The East Pakistan Students' League and the Democratic Students' Federation were among the most active and influential student organizations during this period. They organized rallies, demonstrations, and public meetings to raise awareness about the language issue and demand the recognition of Bengali as a national language.

#### Formation of Language Protection Committees

The formation of Language Protection Committees was a significant development in the language movement. These committees were established to coordinate and intensify the protests against the imposition of Urdu. They were led by prominent students, intellectuals, and cultural activists, who played a crucial role in mobilizing public support for the language movement.

#### Key Figures and Their Contributions

Several key figures emerged as leaders of the language movement, including Abdul Matin, Abdul Jabbar, and Shafiur Rahman. These individuals played a crucial role in organizing and coordinating the protests against the imposition of Urdu. They also contributed to the development of the language movement's objectives and strategies, which focused on the recognition of Bengali as a national language of Pakistan.

#### Objectives and Activities of the Committees

The Language Protection Committees had several objectives, including the recognition of Bengali as a national language of Pakistan, the promotion of Bengali literature and culture, and the protection of the linguistic and cultural rights of the Bengali people. They organized various activities to achieve these objectives, including rallies, demonstrations, public meetings, and cultural events. These activities helped to raise awareness about the language issue and mobilize public support for the language movement.

## 2. Protests of 1948: Early Signs of Resistance

The protests of 1948 marked a significant turning point in the language movement, as they represented the first organized and sustained resistance against the imposition of Urdu as the national language of Pakistan. These protests were characterized by a high level of student activism and public participation, which helped to raise awareness about the language issue and mobilize support for the language movement.

### a. First Language Conference and Student Protests

The first significant language conference was held in Dhaka in March 1948. This conference was organized by the Tamaddun Majlish, a cultural organization that played a crucial role in the language movement. The conference was attended by students, intellectuals, and cultural activists from across East Pakistan, who came together to discuss the language issue and demand the recognition of Bengali as a national language.

#### Overview of the Conference

The language conference was a historic event, as it marked the first organized and sustained resistance against the imposition of Urdu as the national language of Pakistan. The conference was attended by a large number of students, intellectuals, and cultural activists, who came together to discuss the language issue and demand the recognition of Bengali as a national language. The conference was characterized by a high level of enthusiasm and commitment, as participants expressed their determination to resist the imposition of Urdu and protect the linguistic and cultural rights of the Bengali people.

#### Key Demands Raised by Students

The students who attended the language conference raised several key demands, including the recognition of Bengali as a national language of Pakistan, the promotion of Bengali literature and culture, and the protection of the linguistic and cultural rights of the Bengali people. They also demanded the establishment of a language academy to promote the development of the Bengali language and literature. These demands reflected the students' commitment to the language movement and their determination to resist the imposition of Urdu.

### b. Political Leaders’ Stance on the Language Issue

The language issue had significant implications for the political dynamics of Pakistan, as it highlighted the cultural and linguistic differences between the various ethnic groups in the country. Political leaders in East and West Pakistan had varied stances on the language issue, which reflected their political interests and ideological positions.

#### Major Political Figures

Several major political figures played a crucial role in shaping the political dynamics of the language issue. In East Pakistan, political leaders like Huseyn Shaheed Suhrawardy and A.K. Fazlul Huq were vocal advocates of the language movement, as they saw it as a means of protecting the linguistic and cultural rights of the Bengali people. In West Pakistan, political leaders like Mohammad Ali Jinnah and Liaquat Ali Khan were more ambivalent about the language issue, as they saw it as a potential threat to the unity and stability of Pakistan.

#### Impact on Political Dynamics

The language issue had significant implications for the political dynamics of Pakistan, as it highlighted the cultural and linguistic differences between the various ethnic groups in the country. The language movement in East Pakistan challenged the dominant political narrative of Pakistan as a unified and homogeneous nation, as it emphasized the distinct linguistic and cultural identity of the Bengali people. This challenge had significant implications for the political dynamics of Pakistan, as it led to the emergence of new political alliances and rivalries.

### c. Government Response and Suppression Tactics

The Pakistani government responded to the language movement with a range of suppression tactics, aimed at quelling the protests and maintaining the unity and stability of the country. These tactics included the use of force, propaganda, and legal measures, which were designed to intimidate and silence the protesters.

#### Measures to Quell Protests

The Pakistani government employed a range of measures to quell the protests against the imposition of Urdu as the national language. These measures included the use of force, such as the deployment of police and military personnel to disperse the protesters and arrest the leaders of the language movement. The government also employed propaganda tactics, such as the dissemination of anti-Bengali propaganda and the promotion of Urdu as a unifying language.

#### Public Backlash

The government's suppression tactics were met with widespread public backlash, as the Bengali people saw them as an attempt to undermine their linguistic and cultural rights. The use of force by the government only served to intensify the protests, as the Bengali people became more determined to resist the imposition of Urdu and protect their linguistic and cultural identity. The public backlash against the government's suppression tactics helped to mobilize support for the language movement and strengthen the resolve of the protesters.

### d. Growing Tension Between East and West Pakistan

The language issue highlighted the growing tension between East and West Pakistan, as it reflected the cultural and linguistic differences between the two regions. The imposition of Urdu as the national language was seen as a symbol of the dominance of West Pakistan over East Pakistan, as it marginalized the Bengali language and undermined its status as a medium of education, administration, and communication.

#### Escalation of Political Unrest

The language issue contributed to the escalation of political unrest in Pakistan, as it highlighted the cultural and linguistic differences between the various ethnic groups in the country. The language movement in East Pakistan challenged the dominant political narrative of Pakistan as a unified and homogeneous nation, as it emphasized the distinct linguistic and cultural identity of the Bengali people. This challenge had significant implications for the political dynamics of Pakistan, as it led to the emergence of new political alliances and rivalries.

#### Impact on Communal Relations

The language issue also had significant implications for communal relations in Pakistan, as it highlighted the cultural and linguistic differences between the various ethnic groups in the country. The language movement in East Pakistan challenged the dominant political narrative of Pakistan as a unified and homogeneous nation, as it emphasized the distinct linguistic and cultural identity of the Bengali people. This challenge had significant implications for communal relations in Pakistan, as it led to the emergence of new communal tensions and conflicts.

## 3. The Martyrdom of 1952 and Its Symbolism

The events leading up to February 21, 1952, marked a critical juncture in the language movement. The escalating tensions and protests culminated in a tragic confrontation between student activists and the police, resulting in the deaths of several protesters. These martyrs became powerful symbols of the language movement and Bengali nationalism.

### a. Events Leading to February 21, 1952

The period leading up to February 21, 1952, was characterized by a series of key incidents and protests that intensified the language movement. Student activism played a crucial role in mobilizing public support and escalating the resistance against the imposition of Urdu.

#### Key Incidents and Protests

Several key incidents and protests marked the escalation of the language movement in the months leading up to February 21, 1952. These included mass rallies, demonstrations, and public meetings organized by student organizations and Language Protection Committees. The protests were characterized by a high level of enthusiasm and commitment, as students and activists demanded the recognition of Bengali as a national language.

#### Role of Student Activism

Student activism was a driving force behind the language movement. Students from various educational institutions in East Pakistan organized and participated in protests, rallies, and demonstrations. They played a crucial role in mobilizing public support and intensifying the resistance against the imposition of Urdu. The student activists were inspired by a sense of nationalism and a determination to protect the linguistic and cultural rights of the Bengali people.

### b. Details of the Protests and Police Action

The protests on February 21, 1952, were met with a brutal response from the police, resulting in the deaths of several protesters. The events of that day have been documented through firsthand accounts, eyewitness testimonies, and media reports, providing a comprehensive account of the violence and repression that occurred.

#### Accounts of Violence and Repression

The protests on February 21, 1952, were marked by a high level of violence and repression. The police used force to disperse the protesters, resulting in the deaths of several students and activists. Eyewitness accounts and media reports provide a detailed account of the police action, including the use of batons, tear gas, and firearms. The violence and repression were met with widespread public outrage and condemnation.

#### Public Reaction to Police Brutality

The public reaction to the police brutality on February 21, 1952, was characterized by a sense of shock, grief, and anger. The deaths of the protesters were seen as a tragic loss of young lives and a symbol of the government's repressive policies. The public expressed their outrage and condemnation through mass demonstrations, memorial services, and public statements. The events of February 21, 1952, became a rallying point for the language movement and a symbol of the struggle for linguistic and cultural rights.

### c. Profiles of the Language Martyrs

The martyrs of the language movement have become enduring symbols of the struggle for linguistic and cultural rights. Their biographies and contributions to the movement have been preserved and commemorated in Bengali culture and society.

#### Biographies of Key Figures

Several key figures emerged as martyrs of the language movement, including Abdus Salam, Rafiq Uddin Ahmed, Abul Barkat, and Abdul Jabbar. These individuals were students and activists who played a crucial role in the language movement and made the ultimate sacrifice for the cause. Their biographies provide insights into their backgrounds, involvement in the movement, and the circumstances surrounding their deaths.

#### Legacy in the Language Movement

The martyrs of the language movement have left a lasting legacy in Bengali culture and society. Their sacrifice has inspired generations of Bengalis to continue the struggle for linguistic and cultural rights. The memory of the martyrs has been preserved and commemorated through various means, including memorials, cultural events, and educational initiatives. The martyrs have become symbols of the language movement and a source of inspiration for Bengali nationalism.

### d. Immediate Aftermath and Public Reaction

The immediate aftermath of the events of February 21, 1952, was characterized by a sense of national mourning and solidarity. The public reaction to the martyrdom of the protesters had a profound impact on Bengali nationalism and the broader language movement.

#### National Mourning and Solidarity

The events of February 21, 1952, were met with a sense of national mourning and solidarity among the Bengali people. The deaths of the protesters were seen as a tragic loss of young lives and a symbol of the government's repressive policies. The public expressed their grief and solidarity through mass demonstrations, memorial services, and public statements. The events of February 21, 1952, became a rallying point for the language movement and a symbol of the struggle for linguistic and cultural rights.

#### Impact on Bengali Nationalism

The events of February 21, 1952, had a profound impact on Bengali nationalism. The martyrdom of the protesters became a symbol of the struggle for linguistic and cultural rights, inspiring generations of Bengalis to continue the fight for their rights. The language movement became a rallying point for Bengali nationalism, as it emphasized the distinct linguistic and cultural identity of the Bengali people. The events of February 21, 1952, became a turning point in the struggle for Bengali independence and national sovereignty.

## 4. Long-term Impact of the Language Movement

The language movement had a lasting impact on Bengali nationalism, cultural identity, and the struggle for linguistic rights. The recognition of Bengali as a state language, the influence on nationalist sentiment, and the cultural and literary responses to the movement have all contributed to its enduring significance.

### a. Recognition of Bengali as a State Language

The recognition of Bengali as a state language of Pakistan in 1956 was a significant victory for the language movement. This legislative change had profound implications for the linguistic and cultural rights of the Bengali people.

#### Legislative Changes

The recognition of Bengali as a state language of Pakistan was the result of sustained pressure and advocacy by the language movement. The legislative changes that led to this recognition were a significant achievement for the movement, as they affirmed the linguistic and cultural rights of the Bengali people. The recognition of Bengali as a state language had profound implications for education, administration, and communication in East Pakistan.

#### Public Celebrations and Cultural Events

The recognition of Bengali as a state language was celebrated with public celebrations and cultural events. These events reflected the joy and pride of the Bengali people in their linguistic and cultural heritage. The celebrations included mass rallies, cultural performances, and literary events, which highlighted the richness and diversity of the Bengali language and culture. The recognition of Bengali as a state language became a symbol of the struggle for linguistic and cultural rights and a source of inspiration for Bengali nationalism.

### b. Influence on Bengali Nationalist Sentiment

The language movement played a crucial role in shaping Bengali nationalist sentiment. It emphasized the distinct linguistic and cultural identity of the Bengali people and contributed to the struggle for independence and national sovereignty.

#### Role in Shaping Identity

The language movement played a crucial role in shaping the identity of the Bengali people. It emphasized the distinct linguistic and cultural heritage of the Bengali people and contributed to the development of a strong sense of nationalism. The movement highlighted the importance of the Bengali language as a symbol of cultural identity and a means of resistance against oppression. The language movement became a rallying point for Bengali nationalism, as it inspired generations of Bengalis to continue the struggle for their rights.

#### Connection to Future Independence Efforts

The language movement was closely connected to the broader struggle for Bengali independence and national sovereignty. The movement highlighted the cultural and linguistic differences between East and West Pakistan and contributed to the emergence of a distinct Bengali national identity. The language movement became a symbol of the struggle for independence, as it inspired generations of Bengalis to continue the fight for their rights. The movement culminated in the creation of Bangladesh in 1971, marking a significant achievement in the struggle for Bengali independence and national sovereignty.

### c. Cultural and Literary Responses to the Movement

The language movement inspired a rich cultural and literary response, reflecting the struggle for linguistic and cultural rights. Artistic expressions and literary works played a crucial role in preserving and promoting the memory of the movement and its martyrs.

#### Artistic Expressions

The language movement inspired a rich cultural response, including visual arts, music, theater, and cinema. Artistic expressions reflected the struggle for linguistic and cultural rights and played a crucial role in preserving and promoting the memory of the movement. Visual arts, such as paintings and sculptures, depicted the events of the language movement and the martyrs who made the ultimate sacrifice. Music, theater, and cinema also played a crucial role in reflecting the struggle for linguistic and cultural rights and inspiring generations of Bengalis to continue the fight for their rights.

#### Literature Reflecting the Struggle

The language movement inspired a rich literary response, including poetry, fiction, and non-fiction works. Literary works reflected the struggle for linguistic and cultural rights and played a crucial role in preserving and promoting the memory of the movement. Poetry, in particular, became a powerful medium for expressing the emotions and aspirations of the Bengali people. Fiction and non-fiction works also played a crucial role in documenting the events of the language movement and the martyrs who made the ultimate sacrifice. The literary response to the language movement has left a lasting legacy in Bengali culture and society.

### d. International Recognition

The language movement gained international recognition, highlighting the global significance of linguistic rights. The establishment of UNESCO's International Mother Language Day on February 21 has contributed to global awareness and advocacy for linguistic rights.

#### Establishment of International Mother Language Day

The establishment of UNESCO's International Mother Language Day on February 21 was a significant achievement for the language movement. This international recognition highlighted the global significance of linguistic rights and contributed to global awareness and advocacy for linguistic rights. The establishment of International Mother Language Day has inspired similar movements and initiatives around the world, highlighting the universal importance of linguistic rights.

#### Global Awareness of Linguistic Rights

The language movement has contributed to global awareness and advocacy for linguistic rights. The struggle for linguistic and cultural rights in East Pakistan has inspired similar movements and initiatives around the world, highlighting the universal importance of linguistic rights. The language movement has become a symbol of the struggle for linguistic and cultural rights, inspiring generations of people to continue the fight for their rights. The movement has contributed to the development of a global discourse on linguistic rights, highlighting the importance of language as a means of cultural identity and resistance against oppression.

