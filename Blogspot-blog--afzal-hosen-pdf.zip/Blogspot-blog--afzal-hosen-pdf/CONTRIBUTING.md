[![Content Lint Markdown](https://github.com/github/docs/actions/workflows/content-lint-markdown.yml/badge.svg)](https://github.com/github/docs/actions/workflows/content-lint-markdown.yml)
