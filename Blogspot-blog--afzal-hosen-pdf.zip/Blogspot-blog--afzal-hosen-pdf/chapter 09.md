# Chapter 9: Operation Searchlight: The Start of Armed Rebellion (March 1971)

## 1. The Brutality of Operation Searchlight (12,500 words)
- **Military Planning and Objectives**
  - Overview of military strategies
  - Key objectives of the operation
- **Detailed Account of the Crackdown in Dhaka**
  - Timeline of events during the crackdown
  - Key incidents and their significance
- **Targeting of Intellectuals, Students, and Political Leaders**
  - Overview of targeted groups
  - Impact on society and culture
- **Spread of Military Operations Across East Pakistan**
  - Overview of military actions in other regions
  - Public reactions to military presence

## 2. The Declaration of Independence (12,500 words)
- **Sheikh Mujibur Rahman’s Arrest and Declaration**
  - Overview of events leading to the declaration
  - Content of the declaration
- **Formation of the Provisional Government**
  - Key figures involved in the government
  - Objectives and challenges faced
- **Initial Resistance and Chaos**
  - Overview of public response to the declaration
  - Key incidents of resistance
- **Spread of the Independence Declaration Across East Pakistan**
  - Methods of communication and mobilization
  - Impact on public sentiment

## 3. Popular Uprising and Initial Resistance (12,500 words)
- **Spontaneous Civilian Resistance**
  - Overview of grassroots resistance efforts
  - Key events and figures involved
- **Role of Bengali Military and Police Personnel**
  - Overview of defections and support for the uprising
  - Impact on military operations
- **Formation of Local Resistance Groups**
  - Overview of key resistance organizations
  - Strategies employed by these groups
- **Key Battles and Confrontations in the Early Days**
  - Overview of significant confrontations
  - Impact on the overall resistance movement

## 4. International Reaction and Media Coverage (12,500 words)
- **Initial Global Response to the Crisis**
  - Overview of international reactions
  - Key statements from world leaders
- **Role of Foreign Journalists in Reporting the Conflict**
  - Overview of media coverage
  - Impact on public awareness
- **Diplomatic Initiatives and Statements**
  - Overview of diplomatic efforts to address the crisis
  - Key resolutions and statements from international bodies
- **Evacuation of Foreign Nationals**
  - Overview of evacuation efforts
  - Impact on international relations